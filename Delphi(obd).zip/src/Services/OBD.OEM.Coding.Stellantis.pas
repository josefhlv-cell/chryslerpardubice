//------------------------------------------------------------------------------
// UNIT           : OBD.OEM.Coding.Stellantis.pas
// CONTENTS       : Stellantis FCA Proxi configuration wrapper
// VERSION        : 1.0
// TARGET         : Embarcadero Delphi 11 or higher
// AUTHOR         : Ernst Reidinga (ERDesigns)
// STATUS         : Open source under Apache 2.0 library
// COMPATIBILITY  : Windows / macOS / Linux / iOS / Android
// RELEASE DATE   : 08/05/2026
// COPYRIGHT      : © 2024-2026 Ernst Reidinga (ERDesigns)
//------------------------------------------------------------------------------
unit OBD.OEM.Coding.Stellantis;

interface

uses
  System.SysUtils, OBD.OEM.Coding;

//------------------------------------------------------------------------------
// TYPES
//------------------------------------------------------------------------------
type
  EOBDStellantisProxi = class(EOBDCodingError);

  TOBDStellantisProxi = class
  strict private
    FBytes: TBytes;
  public
    /// <summary>
    ///   Create.
    /// </summary>
    constructor Create(const Length: Integer); overload;
    /// <summary>
    ///   Create.
    /// </summary>
    constructor Create(const Bytes: TBytes); overload;
    /// <summary>
    ///   Create from hex.
    /// </summary>
    constructor CreateFromHex(const HexString: string);

    /// <summary>
    ///   Byte count.
    /// </summary>
    function ByteCount: Integer;
    /// <summary>
    ///   Get byte.
    /// </summary>
    function GetByte(const Index: Integer): Byte;
    /// <summary>
    ///   Set byte.
    /// </summary>
    procedure SetByte(const Index: Integer; const Value: Byte);
    /// <summary>
    ///   Get bit.
    /// </summary>
    function GetBit(const ByteIndex, BitIndex: Integer): Boolean;
    /// <summary>
    ///   Set bit.
    /// </summary>
    procedure SetBit(const ByteIndex, BitIndex: Integer; const Value: Boolean);
    /// <summary>
    ///   To bytes.
    /// </summary>
    function ToBytes: TBytes;
    /// <summary>
    ///   To hex.
    /// </summary>
    function ToHex: string;

    /// <summary>
    ///   Compute the Proxi-CRC over the current bytes. The
    ///   polynomial used by FCA / Stellantis for Proxi is not publicly
    ///   documented; this method raises EOBDStellantisProxi until the
    ///   algorithm is supplied (see docs/DATA_GAPS.md).
    /// </summary>
    function ComputeChecksum: Word;

    /// <summary>
    ///   Set the explicit CRC bytes (for callers that have an
    ///   independent verified value, e.g. captured from a wiTECH log).
    ///   Leaves the rest of the payload untouched.
    /// </summary>
    procedure SetChecksum(const Crc: Word; const Offset: Integer);
  end;

//------------------------------------------------------------------------------
// IMPLEMENTATION
//------------------------------------------------------------------------------
implementation

//------------------------------------------------------------------------------
// CREATE
//------------------------------------------------------------------------------
constructor TOBDStellantisProxi.Create(const Length: Integer);
begin
  // Initialize the inherited class
  inherited Create;
  if Length < 1 then
    raise EOBDStellantisProxi.CreateFmt(
      'Proxi length must be >= 1, got %d', [Length]);
  // Allocate FBytes
  SetLength(FBytes, Length);
end;

//------------------------------------------------------------------------------
// CREATE
//------------------------------------------------------------------------------
constructor TOBDStellantisProxi.Create(const Bytes: TBytes);
begin
  // Initialize the inherited class
  inherited Create;
  FBytes := Copy(Bytes);
end;

//------------------------------------------------------------------------------
// CREATE FROM HEX
//------------------------------------------------------------------------------
constructor TOBDStellantisProxi.CreateFromHex(const HexString: string);
begin
  // Initialize the inherited class
  inherited Create;
  FBytes := HexStringToBytes(HexString);
end;

//------------------------------------------------------------------------------
// BYTE COUNT
//------------------------------------------------------------------------------
function TOBDStellantisProxi.ByteCount: Integer;
begin
  Result := Length(FBytes);
end;

//------------------------------------------------------------------------------
// GET BYTE
//------------------------------------------------------------------------------
function TOBDStellantisProxi.GetByte(const Index: Integer): Byte;
begin
  if (Index < 0) or (Index > High(FBytes)) then
    raise EOBDStellantisProxi.CreateFmt(
      'Byte index %d out of range (0..%d)', [Index, High(FBytes)]);
  Result := FBytes[Index];
end;

//------------------------------------------------------------------------------
// SET BYTE
//------------------------------------------------------------------------------
procedure TOBDStellantisProxi.SetByte(const Index: Integer; const Value: Byte);
begin
  if (Index < 0) or (Index > High(FBytes)) then
    raise EOBDStellantisProxi.CreateFmt(
      'Byte index %d out of range (0..%d)', [Index, High(FBytes)]);
  FBytes[Index] := Value;
end;

//------------------------------------------------------------------------------
// GET BIT
//------------------------------------------------------------------------------
function TOBDStellantisProxi.GetBit(const ByteIndex, BitIndex: Integer): Boolean;
begin
  Result := OBD.OEM.Coding.GetBit(FBytes, ByteIndex, BitIndex);
end;

//------------------------------------------------------------------------------
// SET BIT
//------------------------------------------------------------------------------
procedure TOBDStellantisProxi.SetBit(const ByteIndex, BitIndex: Integer;
  const Value: Boolean);
begin
  OBD.OEM.Coding.SetBit(FBytes, ByteIndex, BitIndex, Value);
end;

//------------------------------------------------------------------------------
// TO BYTES
//------------------------------------------------------------------------------
function TOBDStellantisProxi.ToBytes: TBytes;
begin
  Result := Copy(FBytes);
end;

//------------------------------------------------------------------------------
// TO HEX
//------------------------------------------------------------------------------
function TOBDStellantisProxi.ToHex: string;
begin
  Result := BytesToHexString(FBytes);
end;

//------------------------------------------------------------------------------
// COMPUTE CHECKSUM
//------------------------------------------------------------------------------
function TOBDStellantisProxi.ComputeChecksum: Word;
begin
  raise EOBDStellantisProxi.Create(
    'Stellantis Proxi CRC polynomial not available in this build; ' +
    'see docs/DATA_GAPS.md (4.4.stellantis_proxi_crc).');
end;

//------------------------------------------------------------------------------
// SET CHECKSUM
//------------------------------------------------------------------------------
procedure TOBDStellantisProxi.SetChecksum(const Crc: Word; const Offset: Integer);
begin
  if (Offset < 0) or (Offset + 1 > High(FBytes)) then
    raise EOBDStellantisProxi.CreateFmt(
      'Checksum offset %d out of range', [Offset]);
  FBytes[Offset] := Byte(Crc shr 8);
  FBytes[Offset + 1] := Byte(Crc and $FF);
end;

end.
