/** Delphi-OBD vehicle-tree integration types. */
export type Fuel = "gasoline" | "diesel" | "hybrid" | "phev" | "mhev" | "bev" | "cng" | "lpg" | "hydrogen" | "other";
export type Confidence = "verified" | "high" | "medium" | "low" | "unknown";
export type Protocol =
  | "ISO_15765_4_CAN_11B_500K" | "ISO_15765_4_CAN_29B_500K"
  | "ISO_15765_4_CAN_11B_250K" | "ISO_15765_4_CAN_29B_250K"
  | "ISO_14230_4_KWP" | "ISO_14230_4_KWP_FAST" | "ISO_9141_2"
  | "SAE_J1850_PWM" | "SAE_J1850_VPW" | "DoIP";

export interface VehicleProfile {
  id: string; make: string; model: string; generation: string; platform: string;
  yearFrom: number; yearTo: number; engineName: string; engineCode: string;
  displacement: number; powerKw: number; fuel: Fuel; transmission: string;
  ecuType: string; ecuFamily: string; requestAddress: string; responseAddress: string;
  protocol: Protocol; delphiCatalogKey: string; delphiEcuId: string;
  /** Candidate references created from catalog data. They are not proof that every SW variant supports them. */
  supportedFunctionIds: string[]; supportedPidIds: string[]; supportedDidIds: string[];
  supportedRoutineIds: string[]; supportedActuatorTestIds: string[]; supportedAdaptationIds: string[];
  notes?: string; source: string; confidence: Confidence; verified: boolean; version: number;
}
export interface VehicleMakeFile { version: number; make: string; slug: string; vehicles: VehicleProfile[]; }
export interface VehicleTreeManifest { version: number; generatedAt: string; source: string; makes: { slug:string; make:string; file:string; vehicleCount:number }[]; totals:{makes:number;vehicles:number}; delphiCatalogsAvailable:string[]; }

export interface DelphiEcu { address:string; response_address?:string; name:string; common_name?:string; protocol?:Protocol; aliases?:string[]; }
export interface DelphiDecoder { kind:string; scale?:number; offset?:number; unit?:string; length?:number; values?:Record<string,string>; }
export interface DelphiDid { did:string; name:string; description?:string; ecu_address?:string; source?:string; verified?:boolean; decoder?:DelphiDecoder; }
export interface DelphiRoutine { id:string; name:string; description?:string; ecu_address?:string; source?:string; verified?:boolean; start_subfunction?:string; stop_subfunction?:string; result_subfunction?:string; payload?:string; safety_warning?:string; session?:string; security_level?:string; }
export interface DelphiLivePid { mode?:string; pid:string; name:string; description?:string; ecu_address?:string; source?:string; verified?:boolean; decoder?:DelphiDecoder; }
export interface DelphiActuator { id:string; name:string; description?:string; ecu_address?:string; source?:string; verified?:boolean; safety_warning?:string; duration_ms?:number; start_subfunction?:string; payload?:string; session?:string; security_level?:string; }
export interface DelphiAdaptation { id?:string; did?:string; name:string; description?:string; ecu_address?:string; source?:string; verified?:boolean; command?:string; session?:string; security_level?:string; }
export interface DelphiCatalog { version:number; manufacturer_key:string; display_name:string; ecus?:DelphiEcu[]; dids?:DelphiDid[]; routines?:DelphiRoutine[]; live_pids?:DelphiLivePid[]; actuator_tests?:DelphiActuator[]; adaptations?:DelphiAdaptation[]; }

export type FunctionKind = "obd2_pid" | "did" | "live_pid" | "routine" | "actuator_test" | "adaptation" | "dtc_scan" | "ecu_identification" | "raw";
export type SupportLevel = "verified" | "catalog_verified" | "address_match" | "candidate" | "generic";
export interface SupportedFunctionReference {
  id:string; kind:FunctionKind; name:string; description?:string; delphiCatalogKey:string; delphiEcuId:string;
  address:{req:string;resp:string}; command:string; did?:string; routineId?:string; pid?:string; actuatorId?:string; adaptationId?:string;
  decoder?:DelphiDecoder; safety_warning?:string; supportLevel:SupportLevel; verified:boolean;
  requiresSession?:string; requiresSecurityLevel?:string; source?:string;
}
export interface DiagnosticCommandContext { mode:"local"|"remote"; requestAddress:string; responseAddress:string; protocol:Protocol; timeoutMs:number; sessionId?:string; metadata?:Record<string,unknown>; }
export interface DiagnosticTransportResult { rawResponse:string; durationMs:number; ok:boolean; error?:string; }
export interface DiagnosticTransport { sendCommand(command:string,ctx:DiagnosticCommandContext):Promise<DiagnosticTransportResult>; }
export type RunStatus = "ok"|"no_data"|"timeout"|"nrc"|"error"|"unsupported"|"blocked";
export interface DecodedValue { name:string; value:number|string|boolean|null; unit?:string; }
export interface DiagRunResult { status:RunStatus; command:string; requestAddress:string; responseAddress:string; rawResponse:string; decodedValues:DecodedValue[]; dtcList:string[]; nrc?:{sid:string;code:string;description?:string}; humanMessage:string; durationMs:number; error?:string; warnings?:string[]; }
export interface DetectedEcu { requestAddress:string; responseAddress:string; catalogKey:string; ecuId:string; commonName?:string; identification:Record<string,string>; confidence:Confidence; }
export interface ResolverOptions { includeCandidates?:boolean; /** Defaults to true. Unverified write functions remain visible with a warning. */ includeUnverifiedWriteFunctions?:boolean; detectedEcu?:DetectedEcu; }
export interface RunOptions { timeoutMs?:number; sessionId?:string; mode?:"local"|"remote"; /** Deprecated compatibility flag. Unverified functions are executable by default and return a warning. */ allowUnverifiedWrite?:boolean; }
export interface ValidationIssue { id:string; issue:string; severity:"error"|"warning"|"info"; }
export interface ValidationReport { generatedAt:string; totals:{vehicles:number;makes:number;errors:number;warnings:number;unverified:number}; errors:{id:string;issue:string}[]; warnings:{id:string;issue:string}[]; info:{id:string;issue:string}[]; }
