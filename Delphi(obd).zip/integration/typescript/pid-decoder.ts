import type { DecodedValue } from "./types";
import { applyDecoder } from "./did-decoder";

export function decodePidResponse(response: string, pid: string, decoder?: { kind: string; scale?: number; offset?: number; unit?: string }): DecodedValue[] {
  const hex = response.replace(/[^0-9A-Fa-f]/g, "").toUpperCase();
  const pidStripped = pid.replace(/^0x/i, "").toUpperCase().padStart(2, "0");
  // Positive response: 41 <pid> <data...>
  const marker = `41${pidStripped}`;
  const idx = hex.indexOf(marker);
  if (idx < 0) return [];
  const payload = hex.substring(idx + marker.length);
  const name = `PID ${pidStripped}`;

  // Well-known OBD-II formulas take priority over generic decoders.
  const b = (n: number) => parseInt(payload.substring(n * 2, n * 2 + 2), 16);
  switch (pidStripped) {
    case "05": return [{ name: "Coolant temp", value: b(0) - 40, unit: "°C" }];
    case "0C": return [{ name: "Engine RPM", value: (b(0) * 256 + b(1)) / 4, unit: "rpm" }];
    case "0D": return [{ name: "Vehicle speed", value: b(0), unit: "km/h" }];
    case "0F": return [{ name: "Intake air temp", value: b(0) - 40, unit: "°C" }];
    case "10": return [{ name: "MAF", value: (b(0) * 256 + b(1)) / 100, unit: "g/s" }];
    case "11": return [{ name: "Throttle position", value: (b(0) * 100) / 255, unit: "%" }];
    case "42": return [{ name: "Control module voltage", value: (b(0) * 256 + b(1)) / 1000, unit: "V" }];
    case "5C": return [{ name: "Oil temp", value: b(0) - 40, unit: "°C" }];
  }
  return applyDecoder(payload, decoder as any, name);
}
