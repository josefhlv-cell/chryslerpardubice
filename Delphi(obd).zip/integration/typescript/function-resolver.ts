export { listSupportedFunctions as resolveFunctions } from "./ecu-resolver";
