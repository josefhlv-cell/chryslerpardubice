/**
 * ISO 14229-1 UDS NRC decoder. Uses the shipped uds-nrc.json catalog if provided,
 * otherwise falls back to the built-in map.
 */
import type { DelphiCatalog } from "./types";

export interface NrcEntry { sid: string; code: string; description?: string }

let externalMap: Record<string, string> | null = null;

/** Optionally seed the decoder with data from catalogs/uds-nrc.json. */
export function seedNrcMap(entries: { code: string; description?: string; short?: string }[]) {
  const m: Record<string, string> = {};
  for (const e of entries) m[e.code.toUpperCase().replace(/^0X/, "")] = e.description || e.short || "";
  externalMap = m;
}

const BUILTIN: Record<string, string> = {
  "10": "General reject",
  "11": "Service not supported",
  "12": "Sub-function not supported",
  "13": "Incorrect message length or invalid format",
  "14": "Response too long",
  "21": "Busy — repeat request",
  "22": "Conditions not correct",
  "24": "Request sequence error",
  "25": "No response from subnet component",
  "26": "Failure prevents execution of requested action",
  "31": "Request out of range",
  "33": "Security access denied",
  "34": "Authentication required",
  "35": "Invalid key",
  "36": "Exceeded number of attempts",
  "37": "Required time delay not expired",
  "70": "Upload/download not accepted",
  "71": "Transfer data suspended",
  "72": "General programming failure",
  "73": "Wrong block sequence counter",
  "78": "Response pending",
  "7E": "Sub-function not supported in active session",
  "7F": "Service not supported in active session",
};

export function decodeNrc(sidHex: string, codeHex: string): NrcEntry {
  const c = codeHex.toUpperCase();
  const desc = (externalMap && externalMap[c]) || BUILTIN[c] || `NRC ${c}`;
  return { sid: sidHex.toUpperCase(), code: c, description: desc };
}
