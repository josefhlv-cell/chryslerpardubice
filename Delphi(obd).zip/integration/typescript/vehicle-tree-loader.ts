import type {
  VehicleTreeManifest,
  VehicleMakeFile,
  VehicleProfile,
  DelphiCatalog,
} from "./types";

/** Fetch abstraction — pass fetch-compatible function (browser fetch, node undici, etc.). */
export type Fetcher = (path: string) => Promise<Response>;

const defaultFetch: Fetcher = (p) => fetch(p);

export interface LoaderOptions {
  /** Base URL for vehicle tree — e.g. "/vraforge/vehicles" */
  vehiclesBase: string;
  /** Base URL for Delphi catalogs — e.g. "/vraforge/catalogs" */
  catalogsBase: string;
  fetcher?: Fetcher;
}

export class VehicleTreeLoader {
  private manifest?: VehicleTreeManifest;
  private makeCache = new Map<string, VehicleMakeFile>();
  private catalogCache = new Map<string, DelphiCatalog>();
  private opts: LoaderOptions;
  constructor(opts: LoaderOptions) {
    this.opts = { fetcher: defaultFetch, ...opts };
  }
  private async fetchJson<T>(url: string): Promise<T> {
    const r = await (this.opts.fetcher || defaultFetch)(url);
    if (!r.ok) throw new Error(`Fetch failed ${url}: ${r.status}`);
    return (await r.json()) as T;
  }
  async loadManifest(): Promise<VehicleTreeManifest> {
    if (this.manifest) return this.manifest;
    this.manifest = await this.fetchJson<VehicleTreeManifest>(
      `${this.opts.vehiclesBase}/manifest.json`
    );
    return this.manifest;
  }
  async loadMake(slug: string): Promise<VehicleMakeFile> {
    if (this.makeCache.has(slug)) return this.makeCache.get(slug)!;
    const m = await this.loadManifest();
    const entry = m.makes.find((x) => x.slug === slug);
    if (!entry) throw new Error(`Unknown make slug: ${slug}`);
    const file = await this.fetchJson<VehicleMakeFile>(
      `${this.opts.vehiclesBase}/${entry.file}`
    );
    this.makeCache.set(slug, file);
    return file;
  }
  private oemIndex?: Record<string, string>;
  private async loadOemIndex(): Promise<Record<string, string>> {
    if (this.oemIndex) return this.oemIndex;
    try {
      const idx = await this.fetchJson<{ entries: Record<string, string> }>(
        `${this.opts.catalogsBase}/oem-index.json`
      );
      this.oemIndex = idx.entries;
    } catch { this.oemIndex = {}; }
    return this.oemIndex!;
  }
  async loadCatalog(catalogKey: string): Promise<DelphiCatalog> {
    if (this.catalogCache.has(catalogKey)) return this.catalogCache.get(catalogKey)!;
    const idx = await this.loadOemIndex();
    const candidates = [
      idx[catalogKey],
      `${catalogKey.toLowerCase()}.json`,
      `${catalogKey.toLowerCase().replace(/_/g, "-")}.json`,
    ].filter(Boolean) as string[];
    let last: unknown;
    for (const c of candidates) {
      try {
        const cat = await this.fetchJson<DelphiCatalog>(`${this.opts.catalogsBase}/${c}`);
        this.catalogCache.set(catalogKey, cat);
        return cat;
      } catch (e) { last = e; }
    }
    throw new Error(`Delphi catalog not found for key ${catalogKey}: ${String(last)}`);
  }
  async listMakes() { return (await this.loadManifest()).makes; }
  async listModels(makeSlug: string): Promise<string[]> {
    const f = await this.loadMake(makeSlug);
    return uniq(f.vehicles.map((v) => v.model));
  }
  async listGenerations(makeSlug: string, model: string) {
    const f = await this.loadMake(makeSlug);
    return uniq(f.vehicles.filter((v) => v.model === model).map((v) => v.generation));
  }
  async listYears(makeSlug: string, model: string, generation: string) {
    const f = await this.loadMake(makeSlug);
    const set = new Set<number>();
    f.vehicles
      .filter((v) => v.model === model && v.generation === generation)
      .forEach((v) => { for (let y = v.yearFrom; y <= v.yearTo; y++) set.add(y); });
    return [...set].sort((a, b) => a - b);
  }
  async listEngines(makeSlug: string, model: string, generation: string, year: number): Promise<VehicleProfile[]> {
    const f = await this.loadMake(makeSlug);
    return f.vehicles.filter(
      (v) =>
        v.model === model &&
        v.generation === generation &&
        year >= v.yearFrom &&
        year <= v.yearTo
    );
  }
  async getVehicleProfile(id: string): Promise<VehicleProfile | undefined> {
    const m = await this.loadManifest();
    for (const mk of m.makes) {
      const f = await this.loadMake(mk.slug);
      const v = f.vehicles.find((x) => x.id === id);
      if (v) return v;
    }
    return undefined;
  }
}

function uniq<T>(arr: T[]): T[] { return [...new Set(arr)]; }
