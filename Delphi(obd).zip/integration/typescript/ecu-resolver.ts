import type {
  DelphiCatalog, DelphiEcu, VehicleProfile, SupportedFunctionReference,
  ResolverOptions, DetectedEcu,
} from "./types";
import { VehicleTreeLoader } from "./vehicle-tree-loader";

export async function resolveDelphiCatalog(loader:VehicleTreeLoader, profile:VehicleProfile):Promise<DelphiCatalog>{
  return loader.loadCatalog(profile.delphiCatalogKey);
}

export async function resolveEcu(loader:VehicleTreeLoader, profile:VehicleProfile, detected?:DetectedEcu){
  const catalog=await resolveDelphiCatalog(loader,profile);
  const targetAddress=detected?.requestAddress || profile.requestAddress;
  const targetId=detected?.ecuId || profile.delphiEcuId;
  const ecu=(catalog.ecus||[]).find(e=>sameHex(e.address,targetAddress))
    || (catalog.ecus||[]).find(e=>e.name===targetId);
  if(!ecu) throw new Error(`ECU ${targetId} / ${targetAddress} není v katalogu ${profile.delphiCatalogKey}`);
  return {catalog,ecu};
}

export async function listSupportedFunctions(
  loader:VehicleTreeLoader,
  profile:VehicleProfile,
  options:ResolverOptions={},
):Promise<SupportedFunctionReference[]> {
  const {catalog,ecu}=await resolveEcu(loader,profile,options.detectedEcu);
  const req=options.detectedEcu?.requestAddress || ecu.address || profile.requestAddress;
  const resp=options.detectedEcu?.responseAddress || ecu.response_address || profile.responseAddress;
  const key=profile.delphiCatalogKey;
  const out:SupportedFunctionReference[]=[];
  const includeUnverifiedWriteFunctions=options.includeUnverifiedWriteFunctions ?? true;
  const exactProfile=profile.verified && (!options.detectedEcu || options.detectedEcu.confidence==="verified" || options.detectedEcu.confidence==="high");

  // Generic safe functions for the selected ECU.
  out.push(makeFn(`${key}:ecu:id`,"ecu_identification","Identifikace ECU","22 F1 90",key,ecu,req,resp,"generic",true));
  out.push(makeFn(`${key}:dtc:uds`,"dtc_scan","Číst DTC (UDS)","19 02 08",key,ecu,req,resp,"generic",true));
  out.push(makeFn(`${key}:dtc:obd2`,"dtc_scan","Číst uložené OBD-II DTC","03",key,ecu,req,resp,"generic",true));

  const allowedPids=new Set(profile.supportedPidIds||[]);
  for(const p of catalog.live_pids||[]){
    if(!matchesAddress(p.ecu_address,req)) continue;
    if(allowedPids.size && !allowedPids.has(p.pid) && !options.includeCandidates) continue;
    const command=buildPidCommand(p.mode,p.pid);
    if(!command) continue;
    out.push({
      ...makeFn(`${key}:pid:${p.pid}`,"live_pid",p.name,command,key,ecu,req,resp,
        p.verified?"catalog_verified":"address_match",Boolean(p.verified)),
      description:p.description,pid:p.pid,decoder:p.decoder,source:p.source,
    });
  }

  const allowedDids=new Set(profile.supportedDidIds||[]);
  for(const d of catalog.dids||[]){
    if(!matchesAddress(d.ecu_address,req)) continue;
    if(allowedDids.size && !allowedDids.has(d.did) && !options.includeCandidates) continue;
    const h=hex(d.did).padStart(4,"0");
    out.push({
      ...makeFn(`${key}:did:${d.did}`,"did",d.name,`22 ${h.slice(0,2)} ${h.slice(2,4)}`,key,ecu,req,resp,
        d.verified?"catalog_verified":"address_match",Boolean(d.verified)),
      description:d.description,did:d.did,decoder:d.decoder,source:d.source,
    });
  }

  const allowedRoutines=new Set(profile.supportedRoutineIds||[]);
  for(const r of catalog.routines||[]){
    if(!matchesAddress(r.ecu_address,req)) continue;
    const explicitlyMapped=allowedRoutines.has(r.id);
    const safeToExpose=Boolean(r.verified && (explicitlyMapped || exactProfile));
    if(!safeToExpose && !includeUnverifiedWriteFunctions) continue;
    const rid=hex(r.id).padStart(4,"0");
    const sub=hex(r.start_subfunction||"01").padStart(2,"0");
    const payload=normalizePayload(r.payload);
    out.push({
      ...makeFn(`${key}:routine:${r.id}`,"routine",r.name,`31 ${sub} ${rid.slice(0,2)} ${rid.slice(2,4)}${payload?` ${payload}`:""}`,key,ecu,req,resp,
        safeToExpose?"verified":"candidate",safeToExpose),
      description:r.description,routineId:r.id,safety_warning:r.safety_warning || (safeToExpose
        ? "Servisní rutina může změnit stav vozidla. Před spuštěním zkontroluj podmínky."
        : "VAROVÁNÍ: Tato servisní rutina není ověřena pro konkrétní SW variantu ECU. Je povolena pro odborné testování na vlastní odpovědnost. Zkontroluj ECU adresu, relaci, Security Access a podmínky spuštění."),
      requiresSession:r.session,requiresSecurityLevel:r.security_level,source:r.source,
    });
  }

  const allowedActuators=new Set(profile.supportedActuatorTestIds||[]);
  for(const a of catalog.actuator_tests||[]){
    if(!matchesAddress(a.ecu_address,req)) continue;
    const explicitlyMapped=allowedActuators.has(a.id);
    const safeToExpose=Boolean(a.verified && (explicitlyMapped || exactProfile));
    if(!safeToExpose && !includeUnverifiedWriteFunctions) continue;
    const rid=hex(a.id).padStart(4,"0"); const sub=hex(a.start_subfunction||"01").padStart(2,"0");
    const payload=normalizePayload(a.payload);
    out.push({
      ...makeFn(`${key}:actuator:${a.id}`,"actuator_test",a.name,`31 ${sub} ${rid.slice(0,2)} ${rid.slice(2,4)}${payload?` ${payload}`:""}`,key,ecu,req,resp,
        safeToExpose?"verified":"candidate",safeToExpose),
      description:a.description,actuatorId:a.id,safety_warning:a.safety_warning || (safeToExpose
        ? "Akční test může uvést součást do pohybu. Zajisti bezpečný prostor."
        : "VAROVÁNÍ: Tento akční test není ověřen pro konkrétní SW variantu ECU. Je povolen pro odborné testování na vlastní odpovědnost. Součást se může náhle uvést do pohybu."),
      requiresSession:a.session,requiresSecurityLevel:a.security_level,source:a.source,
    });
  }

  const allowedAdaptations=new Set(profile.supportedAdaptationIds||[]);
  for(const a of catalog.adaptations||[]){
    if(!matchesAddress(a.ecu_address,req)) continue;
    const adaptationId=a.id || a.did || a.name;
    const explicitlyMapped=allowedAdaptations.has(adaptationId);
    const safeToExpose=Boolean(a.verified && (explicitlyMapped || exactProfile));
    if(!safeToExpose && !includeUnverifiedWriteFunctions) continue;
    const command=a.command
      ? normalizeCommand(a.command)
      : a.did
        ? `2E ${hex(a.did).padStart(4,"0").slice(0,2)} ${hex(a.did).padStart(4,"0").slice(2,4)}`
        : "";
    if(!command) continue;
    out.push({
      ...makeFn(`${key}:adaptation:${adaptationId}`,"adaptation",a.name,command,key,ecu,req,resp,
        safeToExpose?"verified":"candidate",safeToExpose),
      description:a.description,adaptationId,
      safety_warning:safeToExpose
        ? "Adaptace může změnit uložené hodnoty ECU. Před spuštěním zkontroluj podmínky."
        : "VAROVÁNÍ: Tato adaptace není ověřena pro konkrétní SW variantu ECU. Je povolena pro odborné testování na vlastní odpovědnost. Nesprávné použití může změnit nebo vymazat adaptační hodnoty.",
      requiresSession:a.session,requiresSecurityLevel:a.security_level,source:a.source,
    });
  }
  return dedupe(out);
}

function makeFn(id:SupportedFunctionReference["id"],kind:SupportedFunctionReference["kind"],name:string,command:string,key:string,ecu:DelphiEcu,req:string,resp:string,supportLevel:SupportedFunctionReference["supportLevel"],verified:boolean):SupportedFunctionReference{
  return {id,kind,name,delphiCatalogKey:key,delphiEcuId:ecu.name,address:{req,resp},command,supportLevel,verified};
}
function buildPidCommand(mode:string|undefined,pid:string){ const h=hex(pid); if(mode==="service22"||h.length>2)return `22 ${h.padStart(4,"0").slice(0,2)} ${h.padStart(4,"0").slice(2,4)}`; return `01 ${h.padStart(2,"0")}`; }
function matchesAddress(entry:string|undefined,target:string){ return !entry || sameHex(entry,target); }
function sameHex(a:string,b:string){ return hex(a)===hex(b); }
function hex(v:string){ return (v||"").replace(/^0x/i,"").replace(/[^0-9A-Fa-f]/g,"").toUpperCase(); }
function normalizePayload(v:string|undefined){ return v?hex(v).match(/.{1,2}/g)?.join(" ")||"":""; }
function normalizeCommand(v:string){ return hex(v).match(/.{1,2}/g)?.join(" ")||""; }
function dedupe(items:SupportedFunctionReference[]){ const m=new Map<string,SupportedFunctionReference>(); for(const i of items)m.set(i.id,i); return [...m.values()]; }
