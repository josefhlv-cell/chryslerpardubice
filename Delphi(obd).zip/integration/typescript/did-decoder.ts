import type { DecodedValue } from "./types";

type Decoder = { kind: string; scale?: number; offset?: number; unit?: string; length?: number; values?: Record<string, string> };

export function decodeDidResponse(response: string, did: string, decoder?: Decoder): DecodedValue[] {
  const hex = response.replace(/[^0-9A-Fa-f]/g, "").toUpperCase();
  const didStripped = did.replace(/^0x/i, "").toUpperCase().padStart(4, "0");
  // Positive response: 62 <didHi><didLo> <data...>
  const marker = `62${didStripped}`;
  const idx = hex.indexOf(marker);
  if (idx < 0) return [];
  const payload = hex.substring(idx + marker.length);
  return applyDecoder(payload, decoder, `DID ${didStripped}`);
}

export function applyDecoder(hex: string, decoder: Decoder | undefined, name: string): DecodedValue[] {
  if (!decoder) return [{ name, value: hex, unit: undefined }];
  const bytes: number[] = [];
  for (let i = 0; i + 2 <= hex.length; i += 2) bytes.push(parseInt(hex.substring(i, i + 2), 16));
  const scale = decoder.scale ?? 1;
  const offset = decoder.offset ?? 0;
  const unit = decoder.unit;

  const readUint = (n: number) => {
    let v = 0;
    for (let i = 0; i < n && i < bytes.length; i++) v = (v << 8) | bytes[i];
    return v;
  };
  const readInt = (n: number, bits: number) => {
    let v = readUint(n);
    const max = 1 << (bits - 1);
    if (v >= max) v -= max * 2;
    return v;
  };

  switch (decoder.kind) {
    case "ascii":
      return [{ name, value: bytes.map((b) => String.fromCharCode(b)).join("").replace(/\0+$/, "") }];
    case "hex":
    case "bytes":
    case "raw":
      return [{ name, value: hex }];
    case "uint8":  return [{ name, value: readUint(1) * scale + offset, unit }];
    case "uint16_be": return [{ name, value: readUint(2) * scale + offset, unit }];
    case "uint32_be": return [{ name, value: readUint(4) * scale + offset, unit }];
    case "int8":  return [{ name, value: readInt(1, 8) * scale + offset, unit }];
    case "int16_be": return [{ name, value: readInt(2, 16) * scale + offset, unit }];
    case "int32_be": return [{ name, value: readInt(4, 32) * scale + offset, unit }];
    case "bool":  return [{ name, value: (bytes[0] ?? 0) !== 0 }];
    case "enum": {
      const key = String(readUint(1));
      const lbl = decoder.values?.[key] ?? key;
      return [{ name, value: lbl }];
    }
    default:
      return [{ name, value: hex }];
  }
}
