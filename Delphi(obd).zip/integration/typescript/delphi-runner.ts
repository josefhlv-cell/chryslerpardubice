import type { DiagnosticTransport, DiagRunResult, SupportedFunctionReference, VehicleProfile, RunOptions } from "./types";
export type { RunOptions } from "./types";
import { decodeNrc } from "./nrc-decoder";
import { decodeDtcList } from "./dtc-decoder";
import { decodeDidResponse } from "./did-decoder";
import { decodePidResponse } from "./pid-decoder";

export async function runFunction(transport:DiagnosticTransport,profile:VehicleProfile,fn:SupportedFunctionReference,opts:RunOptions={}):Promise<DiagRunResult>{
  const started=Date.now();
  const isWrite=["routine","actuator_test","adaptation"].includes(fn.kind);
  const warnings:string[]=[];
  if(isWrite && !fn.verified){
    warnings.push(fn.safety_warning || "VAROVÁNÍ: Funkce není ověřena pro konkrétní SW variantu ECU. Spouštíš ji na vlastní odpovědnost.");
  } else if(isWrite && fn.safety_warning){
    warnings.push(fn.safety_warning);
  }
  const attachWarnings=(result:DiagRunResult):DiagRunResult => warnings.length?{...result,warnings}:result;
  const ctx={
    mode:opts.mode??"local", requestAddress:fn.address.req||profile.requestAddress,
    responseAddress:fn.address.resp||profile.responseAddress, protocol:profile.protocol,
    timeoutMs:opts.timeoutMs??(isWrite?10000:3500), sessionId:opts.sessionId,
    metadata:{functionId:fn.id,kind:fn.kind,catalog:fn.delphiCatalogKey,ecu:fn.delphiEcuId,supportLevel:fn.supportLevel,requiresSession:fn.requiresSession,requiresSecurityLevel:fn.requiresSecurityLevel},
  } as const;
  const r=await transport.sendCommand(fn.command,ctx); const dur=Date.now()-started;
  const raw=(r.rawResponse||"").trim(); const cleaned=raw.replace(/[\r\n>]+/g," ").replace(/\s+/g," ").trim();
  if(!r.ok||!cleaned)return attachWarnings(base(fn,cleaned,dur,r.ok?"no_data":"error",r.ok?"Žádná odpověď z ECU":"Transportní chyba",r.error));
  if(/NO\s*DATA/i.test(cleaned))return attachWarnings(base(fn,cleaned,dur,"no_data","ECU nevrátila data (NO DATA)"));
  if(/CAN\s*ERROR|BUS\s*ERROR|UNABLE\s*TO\s*CONNECT/i.test(cleaned))return attachWarnings(base(fn,cleaned,dur,"error",`Sběrnice: ${cleaned}`));
  if(/TIMEOUT/i.test(cleaned))return attachWarnings(base(fn,cleaned,dur,"timeout","Vypršel čas odpovědi ECU"));
  const nrcMatch=cleaned.match(/\b7F\s+([0-9A-F]{2})\s+([0-9A-F]{2})\b/i);
  if(nrcMatch){const nrc=decodeNrc(nrcMatch[1],nrcMatch[2]);return attachWarnings({...base(fn,cleaned,dur,"nrc",nrcMessage(nrc.code,nrc.description)),nrc});}
  if(fn.kind==="dtc_scan"){const dtcs=decodeDtcList(cleaned,fn.command);return attachWarnings({...base(fn,cleaned,dur,"ok",dtcs.length?`Nalezeno ${dtcs.length} DTC`:"Žádné DTC"),dtcList:dtcs});}
  if(fn.kind==="did"&&fn.did){const decoded=decodeDidResponse(cleaned,fn.did,fn.decoder);return attachWarnings({...base(fn,cleaned,dur,decoded.length?"ok":"unsupported",decoded.length?"Hodnota načtena":"DID není podporován"),decodedValues:decoded});}
  if(fn.kind==="live_pid"&&fn.pid){const decoded=decodePidResponse(cleaned,fn.pid,fn.decoder);return attachWarnings({...base(fn,cleaned,dur,decoded.length?"ok":"unsupported",decoded.length?"Hodnota načtena":"PID není podporován"),decodedValues:decoded});}
  if(isWrite){const expected=fn.kind==="adaptation"?/\b6E\b/:/\b71\b/;return attachWarnings(base(fn,cleaned,dur,expected.test(cleaned)?"ok":"unsupported",expected.test(cleaned)?"ECU funkci přijala":"Odpověď neodpovídá očekávané kladné odpovědi"));}
  return attachWarnings(base(fn,cleaned,dur,"ok","Odpověď přijata"));
}
function nrcMessage(code:string,desc?:string){const map:Record<string,string>={"11":"Služba není podporována.","12":"Podfunkce není podporována.","22":"Nejsou splněny podmínky spuštění.","31":"Požadavek nebo identifikátor není pro tuto ECU platný.","33":"Je vyžadován bezpečnostní přístup.","7E":"Funkce není podporována v aktivní relaci.","7F":"Služba není podporována v aktivní relaci.","78":"ECU požadavek stále zpracovává."};return map[code.toUpperCase()]||`ECU požadavek odmítla: ${desc||`NRC 0x${code}`}`;}
function base(fn:SupportedFunctionReference,raw:string,durationMs:number,status:DiagRunResult["status"],humanMessage:string,error?:string):DiagRunResult{return {status,command:fn.command,requestAddress:fn.address.req,responseAddress:fn.address.resp,rawResponse:raw,decodedValues:[],dtcList:[],humanMessage,durationMs,error};}
