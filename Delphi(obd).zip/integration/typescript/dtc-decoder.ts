/** Decode DTC bytes into P/C/B/U codes for OBD-II Mode 03/07/0A + UDS 19 02. */

export function decodeDtcList(response: string, requestCmd: string): string[] {
  const hex = response.replace(/[^0-9A-Fa-f]/g, "").toUpperCase();
  const isUds = /^19/.test(requestCmd.replace(/\s/g, ""));
  const out: string[] = [];

  // Strip response prefix bytes
  // OBD-II: 43 <count> or 43 <bytes...>; UDS: 59 02 <availability mask> <dtc><status>...
  let payload = hex;
  if (isUds) {
    // 59 02 <mask>
    payload = payload.replace(/^59\s*02\s*[0-9A-F]{2}/i, "");
  } else {
    payload = payload.replace(/^4[37A]([0-9A-F]{2})?/i, ""); // 43, 47, 4A + optional count byte
  }

  if (isUds) {
    // <dtcHi><dtcMid><dtcLo><status> chunks of 8 chars
    for (let i = 0; i + 8 <= payload.length; i += 8) {
      const dtc = decode3Byte(payload.substring(i, i + 6));
      if (dtc && dtc !== "P0000") out.push(dtc);
    }
  } else {
    for (let i = 0; i + 4 <= payload.length; i += 4) {
      const dtc = decode2Byte(payload.substring(i, i + 4));
      if (dtc && dtc !== "P0000") out.push(dtc);
    }
  }
  return out;
}

function decode2Byte(h: string): string | null {
  if (h.length !== 4) return null;
  const b0 = parseInt(h.substring(0, 2), 16);
  const b1 = parseInt(h.substring(2, 4), 16);
  return formatDtc(b0, b1);
}
function decode3Byte(h: string): string | null {
  if (h.length !== 6) return null;
  const b0 = parseInt(h.substring(0, 2), 16);
  const b1 = parseInt(h.substring(2, 4), 16);
  // third byte carries the low-order digits, still fits the two-byte formatter
  const b2 = parseInt(h.substring(4, 6), 16);
  const code = formatDtc(b0, b1);
  return code ? code + b2.toString(16).toUpperCase().padStart(2, "0").substring(0, 2) : null;
}
function formatDtc(b0: number, b1: number): string | null {
  if (isNaN(b0) || isNaN(b1)) return null;
  const prefixMap = ["P", "C", "B", "U"];
  const p = prefixMap[(b0 & 0xC0) >> 6];
  const d1 = (b0 & 0x30) >> 4;
  const d2 = b0 & 0x0F;
  const d3 = (b1 & 0xF0) >> 4;
  const d4 = b1 & 0x0F;
  return `${p}${d1}${d2.toString(16).toUpperCase()}${d3.toString(16).toUpperCase()}${d4.toString(16).toUpperCase()}`;
}
